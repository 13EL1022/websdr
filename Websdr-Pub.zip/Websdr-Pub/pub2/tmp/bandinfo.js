var nbands=8;
var ini_freq=3700.000000;
var ini_mode='LSB';
var chseq=2;
var bandinfo= [
  { centerfreq: 1897.450000,
    samplerate: 192.000000,
    tuningstep: 0.031250,
    maxlinbw: 4.000000,
    vfo: 1907.450000,
    maxzoom: 3,
    name: '160m',
    scaleimgs: [
      ["tmp/1463942697-b0z0i0.png"],
      ["tmp/1463942697-b0z1i0.png","tmp/1463942697-b0z1i1.png"],
      ["tmp/1463942697-b0z2i0.png","tmp/1463942697-b0z2i1.png","tmp/1463942697-b0z2i2.png","tmp/1463942697-b0z2i3.png"],
      ["tmp/1463942697-b0z3i0.png","tmp/1463942697-b0z3i1.png","tmp/1463942697-b0z3i2.png","tmp/1463942697-b0z3i3.png","tmp/1463942697-b0z3i4.png","tmp/1463942697-b0z3i5.png","tmp/1463942697-b0z3i6.png","tmp/1463942697-b0z3i7.png"]]
  }
,  { centerfreq: 3695.050000,
    samplerate: 192.000000,
    tuningstep: 0.031250,
    maxlinbw: 4.000000,
    vfo: 3705.050000,
    maxzoom: 3,
    name: '80m',
    scaleimgs: [
      ["tmp/1463942697-b1z0i0.png"],
      ["tmp/1463942697-b1z1i0.png","tmp/1463942697-b1z1i1.png"],
      ["tmp/1463942697-b1z2i0.png","tmp/1463942697-b1z2i1.png","tmp/1463942697-b1z2i2.png","tmp/1463942697-b1z2i3.png"],
      ["tmp/1463942697-b1z3i0.png","tmp/1463942697-b1z3i1.png","tmp/1463942697-b1z3i2.png","tmp/1463942697-b1z3i3.png","tmp/1463942697-b1z3i4.png","tmp/1463942697-b1z3i5.png","tmp/1463942697-b1z3i6.png","tmp/1463942697-b1z3i7.png"]]
  }
,  { centerfreq: 7105.250000,
    samplerate: 192.000000,
    tuningstep: 0.031250,
    maxlinbw: 4.000000,
    vfo: 7115.250000,
    maxzoom: 3,
    name: '40m',
    scaleimgs: [
      ["tmp/1463942697-b2z0i0.png"],
      ["tmp/1463942697-b2z1i0.png","tmp/1463942697-b2z1i1.png"],
      ["tmp/1463942697-b2z2i0.png","tmp/1463942697-b2z2i1.png","tmp/1463942697-b2z2i2.png","tmp/1463942697-b2z2i3.png"],
      ["tmp/1463942697-b2z3i0.png","tmp/1463942697-b2z3i1.png","tmp/1463942697-b2z3i2.png","tmp/1463942697-b2z3i3.png","tmp/1463942697-b2z3i4.png","tmp/1463942697-b2z3i5.png","tmp/1463942697-b2z3i6.png","tmp/1463942697-b2z3i7.png"]]
  }
,  { centerfreq: 14230.000000,
    samplerate: 192.000000,
    tuningstep: 0.031250,
    maxlinbw: 4.000000,
    vfo: 14240.000000,
    maxzoom: 3,
    name: '20m',
    scaleimgs: [
      ["tmp/1463942697-b3z0i0.png"],
      ["tmp/1463942697-b3z1i0.png","tmp/1463942697-b3z1i1.png"],
      ["tmp/1463942697-b3z2i0.png","tmp/1463942697-b3z2i1.png","tmp/1463942697-b3z2i2.png","tmp/1463942697-b3z2i3.png"],
      ["tmp/1463942697-b3z3i0.png","tmp/1463942697-b3z3i1.png","tmp/1463942697-b3z3i2.png","tmp/1463942697-b3z3i3.png","tmp/1463942697-b3z3i4.png","tmp/1463942697-b3z3i5.png","tmp/1463942697-b3z3i6.png","tmp/1463942697-b3z3i7.png"]]
  }
,  { centerfreq: 26980.000000,
    samplerate: 2048.000000,
    tuningstep: 0.031250,
    maxlinbw: 4.000000,
    vfo: 26990.000000,
    maxzoom: 6,
    name: '11m',
    scaleimgs: [
      ["tmp/1463942697-b4z0i0.png"],
      ["tmp/1463942697-b4z1i0.png","tmp/1463942697-b4z1i1.png"],
      ["tmp/1463942697-b4z2i0.png","tmp/1463942697-b4z2i1.png","tmp/1463942697-b4z2i2.png","tmp/1463942697-b4z2i3.png"],
      ["tmp/1463942697-b4z3i0.png","tmp/1463942697-b4z3i1.png","tmp/1463942697-b4z3i2.png","tmp/1463942697-b4z3i3.png","tmp/1463942697-b4z3i4.png","tmp/1463942697-b4z3i5.png","tmp/1463942697-b4z3i6.png","tmp/1463942697-b4z3i7.png"],
      ["tmp/1463942697-b4z4i0.png","tmp/1463942697-b4z4i1.png","tmp/1463942697-b4z4i2.png","tmp/1463942697-b4z4i3.png","tmp/1463942697-b4z4i4.png","tmp/1463942697-b4z4i5.png","tmp/1463942697-b4z4i6.png","tmp/1463942697-b4z4i7.png","tmp/1463942697-b4z4i8.png","tmp/1463942697-b4z4i9.png","tmp/1463942697-b4z4i10.png","tmp/1463942697-b4z4i11.png","tmp/1463942697-b4z4i12.png","tmp/1463942697-b4z4i13.png","tmp/1463942697-b4z4i14.png","tmp/1463942697-b4z4i15.png"],
      ["tmp/1463942697-b4z5i0.png","tmp/1463942697-b4z5i1.png","tmp/1463942697-b4z5i2.png","tmp/1463942697-b4z5i3.png","tmp/1463942697-b4z5i4.png","tmp/1463942697-b4z5i5.png","tmp/1463942697-b4z5i6.png","tmp/1463942697-b4z5i7.png","tmp/1463942697-b4z5i8.png","tmp/1463942697-b4z5i9.png","tmp/1463942697-b4z5i10.png","tmp/1463942697-b4z5i11.png","tmp/1463942697-b4z5i12.png","tmp/1463942697-b4z5i13.png","tmp/1463942697-b4z5i14.png","tmp/1463942697-b4z5i15.png","tmp/1463942697-b4z5i16.png","tmp/1463942697-b4z5i17.png","tmp/1463942697-b4z5i18.png","tmp/1463942697-b4z5i19.png","tmp/1463942697-b4z5i20.png","tmp/1463942697-b4z5i21.png","tmp/1463942697-b4z5i22.png","tmp/1463942697-b4z5i23.png","tmp/1463942697-b4z5i24.png","tmp/1463942697-b4z5i25.png","tmp/1463942697-b4z5i26.png","tmp/1463942697-b4z5i27.png","tmp/1463942697-b4z5i28.png","tmp/1463942697-b4z5i29.png","tmp/1463942697-b4z5i30.png","tmp/1463942697-b4z5i31.png"],
      ["tmp/1463942697-b4z6i0.png","tmp/1463942697-b4z6i1.png","tmp/1463942697-b4z6i2.png","tmp/1463942697-b4z6i3.png","tmp/1463942697-b4z6i4.png","tmp/1463942697-b4z6i5.png","tmp/1463942697-b4z6i6.png","tmp/1463942697-b4z6i7.png","tmp/1463942697-b4z6i8.png","tmp/1463942697-b4z6i9.png","tmp/1463942697-b4z6i10.png","tmp/1463942697-b4z6i11.png","tmp/1463942697-b4z6i12.png","tmp/1463942697-b4z6i13.png","tmp/1463942697-b4z6i14.png","tmp/1463942697-b4z6i15.png","tmp/1463942697-b4z6i16.png","tmp/1463942697-b4z6i17.png","tmp/1463942697-b4z6i18.png","tmp/1463942697-b4z6i19.png","tmp/1463942697-b4z6i20.png","tmp/1463942697-b4z6i21.png","tmp/1463942697-b4z6i22.png","tmp/1463942697-b4z6i23.png","tmp/1463942697-b4z6i24.png","tmp/1463942697-b4z6i25.png","tmp/1463942697-b4z6i26.png","tmp/1463942697-b4z6i27.png","tmp/1463942697-b4z6i28.png","tmp/1463942697-b4z6i29.png","tmp/1463942697-b4z6i30.png","tmp/1463942697-b4z6i31.png","tmp/1463942697-b4z6i32.png","tmp/1463942697-b4z6i33.png","tmp/1463942697-b4z6i34.png","tmp/1463942697-b4z6i35.png","tmp/1463942697-b4z6i36.png","tmp/1463942697-b4z6i37.png","tmp/1463942697-b4z6i38.png","tmp/1463942697-b4z6i39.png","tmp/1463942697-b4z6i40.png","tmp/1463942697-b4z6i41.png","tmp/1463942697-b4z6i42.png","tmp/1463942697-b4z6i43.png","tmp/1463942697-b4z6i44.png","tmp/1463942697-b4z6i45.png","tmp/1463942697-b4z6i46.png","tmp/1463942697-b4z6i47.png","tmp/1463942697-b4z6i48.png","tmp/1463942697-b4z6i49.png","tmp/1463942697-b4z6i50.png","tmp/1463942697-b4z6i51.png","tmp/1463942697-b4z6i52.png","tmp/1463942697-b4z6i53.png","tmp/1463942697-b4z6i54.png","tmp/1463942697-b4z6i55.png","tmp/1463942697-b4z6i56.png","tmp/1463942697-b4z6i57.png","tmp/1463942697-b4z6i58.png","tmp/1463942697-b4z6i59.png","tmp/1463942697-b4z6i60.png","tmp/1463942697-b4z6i61.png","tmp/1463942697-b4z6i62.png","tmp/1463942697-b4z6i63.png"]]
  }
,  { centerfreq: 28980.000000,
    samplerate: 2048.000000,
    tuningstep: 0.031250,
    maxlinbw: 4.000000,
    vfo: 28990.000000,
    maxzoom: 6,
    name: '10 m',
    scaleimgs: [
      ["tmp/1463942697-b5z0i0.png"],
      ["tmp/1463942697-b5z1i0.png","tmp/1463942697-b5z1i1.png"],
      ["tmp/1463942697-b5z2i0.png","tmp/1463942697-b5z2i1.png","tmp/1463942697-b5z2i2.png","tmp/1463942697-b5z2i3.png"],
      ["tmp/1463942697-b5z3i0.png","tmp/1463942697-b5z3i1.png","tmp/1463942697-b5z3i2.png","tmp/1463942697-b5z3i3.png","tmp/1463942697-b5z3i4.png","tmp/1463942697-b5z3i5.png","tmp/1463942697-b5z3i6.png","tmp/1463942697-b5z3i7.png"],
      ["tmp/1463942697-b5z4i0.png","tmp/1463942697-b5z4i1.png","tmp/1463942697-b5z4i2.png","tmp/1463942697-b5z4i3.png","tmp/1463942697-b5z4i4.png","tmp/1463942697-b5z4i5.png","tmp/1463942697-b5z4i6.png","tmp/1463942697-b5z4i7.png","tmp/1463942697-b5z4i8.png","tmp/1463942697-b5z4i9.png","tmp/1463942697-b5z4i10.png","tmp/1463942697-b5z4i11.png","tmp/1463942697-b5z4i12.png","tmp/1463942697-b5z4i13.png","tmp/1463942697-b5z4i14.png","tmp/1463942697-b5z4i15.png"],
      ["tmp/1463942697-b5z5i0.png","tmp/1463942697-b5z5i1.png","tmp/1463942697-b5z5i2.png","tmp/1463942697-b5z5i3.png","tmp/1463942697-b5z5i4.png","tmp/1463942697-b5z5i5.png","tmp/1463942697-b5z5i6.png","tmp/1463942697-b5z5i7.png","tmp/1463942697-b5z5i8.png","tmp/1463942697-b5z5i9.png","tmp/1463942697-b5z5i10.png","tmp/1463942697-b5z5i11.png","tmp/1463942697-b5z5i12.png","tmp/1463942697-b5z5i13.png","tmp/1463942697-b5z5i14.png","tmp/1463942697-b5z5i15.png","tmp/1463942697-b5z5i16.png","tmp/1463942697-b5z5i17.png","tmp/1463942697-b5z5i18.png","tmp/1463942697-b5z5i19.png","tmp/1463942697-b5z5i20.png","tmp/1463942697-b5z5i21.png","tmp/1463942697-b5z5i22.png","tmp/1463942697-b5z5i23.png","tmp/1463942697-b5z5i24.png","tmp/1463942697-b5z5i25.png","tmp/1463942697-b5z5i26.png","tmp/1463942697-b5z5i27.png","tmp/1463942697-b5z5i28.png","tmp/1463942697-b5z5i29.png","tmp/1463942697-b5z5i30.png","tmp/1463942697-b5z5i31.png"],
      ["tmp/1463942697-b5z6i0.png","tmp/1463942697-b5z6i1.png","tmp/1463942697-b5z6i2.png","tmp/1463942697-b5z6i3.png","tmp/1463942697-b5z6i4.png","tmp/1463942697-b5z6i5.png","tmp/1463942697-b5z6i6.png","tmp/1463942697-b5z6i7.png","tmp/1463942697-b5z6i8.png","tmp/1463942697-b5z6i9.png","tmp/1463942697-b5z6i10.png","tmp/1463942697-b5z6i11.png","tmp/1463942697-b5z6i12.png","tmp/1463942697-b5z6i13.png","tmp/1463942697-b5z6i14.png","tmp/1463942697-b5z6i15.png","tmp/1463942697-b5z6i16.png","tmp/1463942697-b5z6i17.png","tmp/1463942697-b5z6i18.png","tmp/1463942697-b5z6i19.png","tmp/1463942697-b5z6i20.png","tmp/1463942697-b5z6i21.png","tmp/1463942697-b5z6i22.png","tmp/1463942697-b5z6i23.png","tmp/1463942697-b5z6i24.png","tmp/1463942697-b5z6i25.png","tmp/1463942697-b5z6i26.png","tmp/1463942697-b5z6i27.png","tmp/1463942697-b5z6i28.png","tmp/1463942697-b5z6i29.png","tmp/1463942697-b5z6i30.png","tmp/1463942697-b5z6i31.png","tmp/1463942697-b5z6i32.png","tmp/1463942697-b5z6i33.png","tmp/1463942697-b5z6i34.png","tmp/1463942697-b5z6i35.png","tmp/1463942697-b5z6i36.png","tmp/1463942697-b5z6i37.png","tmp/1463942697-b5z6i38.png","tmp/1463942697-b5z6i39.png","tmp/1463942697-b5z6i40.png","tmp/1463942697-b5z6i41.png","tmp/1463942697-b5z6i42.png","tmp/1463942697-b5z6i43.png","tmp/1463942697-b5z6i44.png","tmp/1463942697-b5z6i45.png","tmp/1463942697-b5z6i46.png","tmp/1463942697-b5z6i47.png","tmp/1463942697-b5z6i48.png","tmp/1463942697-b5z6i49.png","tmp/1463942697-b5z6i50.png","tmp/1463942697-b5z6i51.png","tmp/1463942697-b5z6i52.png","tmp/1463942697-b5z6i53.png","tmp/1463942697-b5z6i54.png","tmp/1463942697-b5z6i55.png","tmp/1463942697-b5z6i56.png","tmp/1463942697-b5z6i57.png","tmp/1463942697-b5z6i58.png","tmp/1463942697-b5z6i59.png","tmp/1463942697-b5z6i60.png","tmp/1463942697-b5z6i61.png","tmp/1463942697-b5z6i62.png","tmp/1463942697-b5z6i63.png"]]
  }
,  { centerfreq: 145201.000000,
    samplerate: 2048.000000,
    tuningstep: 0.031250,
    maxlinbw: 4.000000,
    vfo: 145211.000000,
    maxzoom: 6,
    name: '2 m',
    scaleimgs: [
      ["tmp/1463942697-b6z0i0.png"],
      ["tmp/1463942697-b6z1i0.png","tmp/1463942697-b6z1i1.png"],
      ["tmp/1463942697-b6z2i0.png","tmp/1463942697-b6z2i1.png","tmp/1463942697-b6z2i2.png","tmp/1463942697-b6z2i3.png"],
      ["tmp/1463942697-b6z3i0.png","tmp/1463942697-b6z3i1.png","tmp/1463942697-b6z3i2.png","tmp/1463942697-b6z3i3.png","tmp/1463942697-b6z3i4.png","tmp/1463942697-b6z3i5.png","tmp/1463942697-b6z3i6.png","tmp/1463942697-b6z3i7.png"],
      ["tmp/1463942697-b6z4i0.png","tmp/1463942697-b6z4i1.png","tmp/1463942697-b6z4i2.png","tmp/1463942697-b6z4i3.png","tmp/1463942697-b6z4i4.png","tmp/1463942697-b6z4i5.png","tmp/1463942697-b6z4i6.png","tmp/1463942697-b6z4i7.png","tmp/1463942697-b6z4i8.png","tmp/1463942697-b6z4i9.png","tmp/1463942697-b6z4i10.png","tmp/1463942697-b6z4i11.png","tmp/1463942697-b6z4i12.png","tmp/1463942697-b6z4i13.png","tmp/1463942697-b6z4i14.png","tmp/1463942697-b6z4i15.png"],
      ["tmp/1463942697-b6z5i0.png","tmp/1463942697-b6z5i1.png","tmp/1463942697-b6z5i2.png","tmp/1463942697-b6z5i3.png","tmp/1463942697-b6z5i4.png","tmp/1463942697-b6z5i5.png","tmp/1463942697-b6z5i6.png","tmp/1463942697-b6z5i7.png","tmp/1463942697-b6z5i8.png","tmp/1463942697-b6z5i9.png","tmp/1463942697-b6z5i10.png","tmp/1463942697-b6z5i11.png","tmp/1463942697-b6z5i12.png","tmp/1463942697-b6z5i13.png","tmp/1463942697-b6z5i14.png","tmp/1463942697-b6z5i15.png","tmp/1463942697-b6z5i16.png","tmp/1463942697-b6z5i17.png","tmp/1463942697-b6z5i18.png","tmp/1463942697-b6z5i19.png","tmp/1463942697-b6z5i20.png","tmp/1463942697-b6z5i21.png","tmp/1463942697-b6z5i22.png","tmp/1463942697-b6z5i23.png","tmp/1463942697-b6z5i24.png","tmp/1463942697-b6z5i25.png","tmp/1463942697-b6z5i26.png","tmp/1463942697-b6z5i27.png","tmp/1463942697-b6z5i28.png","tmp/1463942697-b6z5i29.png","tmp/1463942697-b6z5i30.png","tmp/1463942697-b6z5i31.png"],
      ["tmp/1463942697-b6z6i0.png","tmp/1463942697-b6z6i1.png","tmp/1463942697-b6z6i2.png","tmp/1463942697-b6z6i3.png","tmp/1463942697-b6z6i4.png","tmp/1463942697-b6z6i5.png","tmp/1463942697-b6z6i6.png","tmp/1463942697-b6z6i7.png","tmp/1463942697-b6z6i8.png","tmp/1463942697-b6z6i9.png","tmp/1463942697-b6z6i10.png","tmp/1463942697-b6z6i11.png","tmp/1463942697-b6z6i12.png","tmp/1463942697-b6z6i13.png","tmp/1463942697-b6z6i14.png","tmp/1463942697-b6z6i15.png","tmp/1463942697-b6z6i16.png","tmp/1463942697-b6z6i17.png","tmp/1463942697-b6z6i18.png","tmp/1463942697-b6z6i19.png","tmp/1463942697-b6z6i20.png","tmp/1463942697-b6z6i21.png","tmp/1463942697-b6z6i22.png","tmp/1463942697-b6z6i23.png","tmp/1463942697-b6z6i24.png","tmp/1463942697-b6z6i25.png","tmp/1463942697-b6z6i26.png","tmp/1463942697-b6z6i27.png","tmp/1463942697-b6z6i28.png","tmp/1463942697-b6z6i29.png","tmp/1463942697-b6z6i30.png","tmp/1463942697-b6z6i31.png","tmp/1463942697-b6z6i32.png","tmp/1463942697-b6z6i33.png","tmp/1463942697-b6z6i34.png","tmp/1463942697-b6z6i35.png","tmp/1463942697-b6z6i36.png","tmp/1463942697-b6z6i37.png","tmp/1463942697-b6z6i38.png","tmp/1463942697-b6z6i39.png","tmp/1463942697-b6z6i40.png","tmp/1463942697-b6z6i41.png","tmp/1463942697-b6z6i42.png","tmp/1463942697-b6z6i43.png","tmp/1463942697-b6z6i44.png","tmp/1463942697-b6z6i45.png","tmp/1463942697-b6z6i46.png","tmp/1463942697-b6z6i47.png","tmp/1463942697-b6z6i48.png","tmp/1463942697-b6z6i49.png","tmp/1463942697-b6z6i50.png","tmp/1463942697-b6z6i51.png","tmp/1463942697-b6z6i52.png","tmp/1463942697-b6z6i53.png","tmp/1463942697-b6z6i54.png","tmp/1463942697-b6z6i55.png","tmp/1463942697-b6z6i56.png","tmp/1463942697-b6z6i57.png","tmp/1463942697-b6z6i58.png","tmp/1463942697-b6z6i59.png","tmp/1463942697-b6z6i60.png","tmp/1463942697-b6z6i61.png","tmp/1463942697-b6z6i62.png","tmp/1463942697-b6z6i63.png"]]
  }
,  { centerfreq: 438909.000000,
    samplerate: 2048.000000,
    tuningstep: 0.031250,
    maxlinbw: 4.000000,
    vfo: 438919.000000,
    maxzoom: 6,
    name: '70 cm',
    scaleimgs: [
      ["tmp/1463942697-b7z0i0.png"],
      ["tmp/1463942697-b7z1i0.png","tmp/1463942697-b7z1i1.png"],
      ["tmp/1463942697-b7z2i0.png","tmp/1463942697-b7z2i1.png","tmp/1463942697-b7z2i2.png","tmp/1463942697-b7z2i3.png"],
      ["tmp/1463942697-b7z3i0.png","tmp/1463942697-b7z3i1.png","tmp/1463942697-b7z3i2.png","tmp/1463942697-b7z3i3.png","tmp/1463942697-b7z3i4.png","tmp/1463942697-b7z3i5.png","tmp/1463942697-b7z3i6.png","tmp/1463942697-b7z3i7.png"],
      ["tmp/1463942697-b7z4i0.png","tmp/1463942697-b7z4i1.png","tmp/1463942697-b7z4i2.png","tmp/1463942697-b7z4i3.png","tmp/1463942697-b7z4i4.png","tmp/1463942697-b7z4i5.png","tmp/1463942697-b7z4i6.png","tmp/1463942697-b7z4i7.png","tmp/1463942697-b7z4i8.png","tmp/1463942697-b7z4i9.png","tmp/1463942697-b7z4i10.png","tmp/1463942697-b7z4i11.png","tmp/1463942697-b7z4i12.png","tmp/1463942697-b7z4i13.png","tmp/1463942697-b7z4i14.png","tmp/1463942697-b7z4i15.png"],
      ["tmp/1463942697-b7z5i0.png","tmp/1463942697-b7z5i1.png","tmp/1463942697-b7z5i2.png","tmp/1463942697-b7z5i3.png","tmp/1463942697-b7z5i4.png","tmp/1463942697-b7z5i5.png","tmp/1463942697-b7z5i6.png","tmp/1463942697-b7z5i7.png","tmp/1463942697-b7z5i8.png","tmp/1463942697-b7z5i9.png","tmp/1463942697-b7z5i10.png","tmp/1463942697-b7z5i11.png","tmp/1463942697-b7z5i12.png","tmp/1463942697-b7z5i13.png","tmp/1463942697-b7z5i14.png","tmp/1463942697-b7z5i15.png","tmp/1463942697-b7z5i16.png","tmp/1463942697-b7z5i17.png","tmp/1463942697-b7z5i18.png","tmp/1463942697-b7z5i19.png","tmp/1463942697-b7z5i20.png","tmp/1463942697-b7z5i21.png","tmp/1463942697-b7z5i22.png","tmp/1463942697-b7z5i23.png","tmp/1463942697-b7z5i24.png","tmp/1463942697-b7z5i25.png","tmp/1463942697-b7z5i26.png","tmp/1463942697-b7z5i27.png","tmp/1463942697-b7z5i28.png","tmp/1463942697-b7z5i29.png","tmp/1463942697-b7z5i30.png","tmp/1463942697-b7z5i31.png"],
      ["tmp/1463942697-b7z6i0.png","tmp/1463942697-b7z6i1.png","tmp/1463942697-b7z6i2.png","tmp/1463942697-b7z6i3.png","tmp/1463942697-b7z6i4.png","tmp/1463942697-b7z6i5.png","tmp/1463942697-b7z6i6.png","tmp/1463942697-b7z6i7.png","tmp/1463942697-b7z6i8.png","tmp/1463942697-b7z6i9.png","tmp/1463942697-b7z6i10.png","tmp/1463942697-b7z6i11.png","tmp/1463942697-b7z6i12.png","tmp/1463942697-b7z6i13.png","tmp/1463942697-b7z6i14.png","tmp/1463942697-b7z6i15.png","tmp/1463942697-b7z6i16.png","tmp/1463942697-b7z6i17.png","tmp/1463942697-b7z6i18.png","tmp/1463942697-b7z6i19.png","tmp/1463942697-b7z6i20.png","tmp/1463942697-b7z6i21.png","tmp/1463942697-b7z6i22.png","tmp/1463942697-b7z6i23.png","tmp/1463942697-b7z6i24.png","tmp/1463942697-b7z6i25.png","tmp/1463942697-b7z6i26.png","tmp/1463942697-b7z6i27.png","tmp/1463942697-b7z6i28.png","tmp/1463942697-b7z6i29.png","tmp/1463942697-b7z6i30.png","tmp/1463942697-b7z6i31.png","tmp/1463942697-b7z6i32.png","tmp/1463942697-b7z6i33.png","tmp/1463942697-b7z6i34.png","tmp/1463942697-b7z6i35.png","tmp/1463942697-b7z6i36.png","tmp/1463942697-b7z6i37.png","tmp/1463942697-b7z6i38.png","tmp/1463942697-b7z6i39.png","tmp/1463942697-b7z6i40.png","tmp/1463942697-b7z6i41.png","tmp/1463942697-b7z6i42.png","tmp/1463942697-b7z6i43.png","tmp/1463942697-b7z6i44.png","tmp/1463942697-b7z6i45.png","tmp/1463942697-b7z6i46.png","tmp/1463942697-b7z6i47.png","tmp/1463942697-b7z6i48.png","tmp/1463942697-b7z6i49.png","tmp/1463942697-b7z6i50.png","tmp/1463942697-b7z6i51.png","tmp/1463942697-b7z6i52.png","tmp/1463942697-b7z6i53.png","tmp/1463942697-b7z6i54.png","tmp/1463942697-b7z6i55.png","tmp/1463942697-b7z6i56.png","tmp/1463942697-b7z6i57.png","tmp/1463942697-b7z6i58.png","tmp/1463942697-b7z6i59.png","tmp/1463942697-b7z6i60.png","tmp/1463942697-b7z6i61.png","tmp/1463942697-b7z6i62.png","tmp/1463942697-b7z6i63.png"]]
  }
];
var dxinfoavailable=1;
var idletimeout=0;
var has_mobile=0;
